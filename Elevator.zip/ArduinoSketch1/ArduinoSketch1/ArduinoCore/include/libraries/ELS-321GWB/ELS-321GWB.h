void clear_display();
void counter();
void reverse_counter();
void print_number(int a);
void dice();

