/*
 * ArduinoCore.cpp
 *
 * Created: 06/03/2017 11:48:44
 * Author : fille
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

