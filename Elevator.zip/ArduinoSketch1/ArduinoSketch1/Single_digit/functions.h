void light_it_up(void);
